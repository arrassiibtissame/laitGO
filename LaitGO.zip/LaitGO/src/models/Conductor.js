export default class Conductor {
  constructor({ id, name, truckId, phone, email }) {
    this.id = id;
    this.name = name;
    this.truckId = truckId;
    this.phone = phone;
    this.email = email;
  }
} 