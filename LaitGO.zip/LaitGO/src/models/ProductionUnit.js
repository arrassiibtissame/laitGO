export default class ProductionUnit {
  constructor({ id, name, location, memberId }) {
    this.id = id;
    this.name = name;
    this.location = location;
    this.memberId = memberId;
  }
} 