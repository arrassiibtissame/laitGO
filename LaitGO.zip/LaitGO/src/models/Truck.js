export default class Truck {
  constructor({ id, matricule, capacity, conductorId }) {
    this.id = id;
    this.matricule = matricule;
    this.capacity = capacity;
    this.conductorId = conductorId;
  }
} 